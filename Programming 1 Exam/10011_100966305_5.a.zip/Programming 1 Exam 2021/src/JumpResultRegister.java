import java.time.LocalTime;
import java.util.*;

/**
 * This is a class representing the register for a long jump event. It, therefore, uses an arrayList to store the
 * different long jump entries/results of the event. An arrayList is used since it does not have a defined length and
 * can therefore be made longer if necessary, or removed if needed. In that sense, an array list allows for more
 * flexibility when handling the entries.
 *
 * @author 10011
 */
public class JumpResultRegister{
    private final List<LongJumpResult> JUMP_RESULT_REGISTER;
    private final String NAME_OF_EVENT;

    /**
     * This is the constructor representing a register. Therefore, an arrayList is initialized when a new JumpResultRegister
     * object is instantiated.
     * @param NAME_OF_EVENT The name of the event, f.eks Olympic Games 2021.
     */
    public JumpResultRegister(String NAME_OF_EVENT) {
        this.JUMP_RESULT_REGISTER = new ArrayList<>();
        this.NAME_OF_EVENT = NAME_OF_EVENT;
    }

    /**
     * This method registers a new LongJumpResult object to the JUMP_RESULT_REGISTER. Since the register does not want
     * duplicates of the same jump, the input provided is check to see if there already exists an identical object. The
     * checkSameNameAndNum method {@link #checkSameNameAndNum(String, String)} is used in order to make sure the athlete
     * has only one start number.
     * @param START_NUMBER A string with start number of athlete.
     * @param ATHLETE_NAME A string with the athlete's name.
     * @param JUMP_RESULT A double with the jump result.
     * @param FOUL A boolean of whether the jump was valid or not.
     * @param TIME_OF_JUMP A LocalTime object, showing the when the jump took place.
     * @return A boolean stating whether the jump result was successfully added to the registry.
     */
    public boolean registerNewJump(String START_NUMBER, String ATHLETE_NAME, double JUMP_RESULT, boolean FOUL, LocalTime TIME_OF_JUMP){
        LongJumpResult longJumpResult = new LongJumpResult(START_NUMBER, ATHLETE_NAME, JUMP_RESULT, FOUL, TIME_OF_JUMP);
        if(this.JUMP_RESULT_REGISTER.contains(longJumpResult)){
            return false;
        }
        if(!checkSameNameAndNum(ATHLETE_NAME, START_NUMBER)){
            return false;
        }
        this.JUMP_RESULT_REGISTER.add(longJumpResult);
        chronologicalResults();
        return true;
    }

    /**
     * This method returns a deep copied version of the register.
     * @return The main register as a list containing LongJumpResult.
     */
    public List<LongJumpResult> listAllJumps(){
        return deepCopyList(this.JUMP_RESULT_REGISTER);
    }

    /**
     * This method returns all the jump attempts/results of a given athlete. The list is made by going through each
     * entry in the registry and checking if the input athlete has the same name as the object variable name.
     * @param athleteName A string for athlete's name.
     * @return A deep copied list of all the entries that the athlete has on the registry. The list contains
     *         LongJumpResult objects.
     */
    public List<LongJumpResult> resultByAthlete(String athleteName){
        if(athleteName.isBlank()) throw new IllegalArgumentException("Please enter an athlete's name.");
        List<LongJumpResult> athletesResult = new ArrayList<>();
        for(LongJumpResult longJumpResult : JUMP_RESULT_REGISTER){
            if(longJumpResult.getATHLETE_NAME().equals(athleteName.toUpperCase())){
                athletesResult.add(longJumpResult);
            }
        }
        return deepCopyList(athletesResult);
    }

    /**
     * This method find the best three jump results in all the entries within the register.
     * @param numberOfPlaces The number of best results
     * @return A list of the three best jumps, the list contains LongJumpResult objects.
     */
    public List<LongJumpResult> bestResults(int numberOfPlaces){
        List<LongJumpResult> sortByResults = this.JUMP_RESULT_REGISTER;
        Collections.sort(sortByResults, Comparator.comparing(LongJumpResult :: getJUMP_RESULT).reversed());
        List<LongJumpResult> topThreeResults = new ArrayList<>();

        int index = 0;
        while(index < this.JUMP_RESULT_REGISTER.size() && index < numberOfPlaces){
            topThreeResults.add(sortByResults.get(index));
            index++;
        }

        return deepCopyList(topThreeResults);
    }

    /**
     * This method makes sure the main register is always in chronological order
     */
    private void chronologicalResults(){
        Collections.sort(this.JUMP_RESULT_REGISTER, Comparator.comparing(LongJumpResult::getTIME_OF_JUMP));
    }

    /**
     * This method makes sure that an athlete does not have a different start number for each different entry. If the name
     * of the athlete is the same as an earlier entry, but the start number is different false is returned.
     * @param nameOfAthlete Name of the athlete.
     * @param numberOfAthlete Start number of the athlete.
     * @return A boolean, stating false if the athlete has an entry from before with a different start value and otherwise, true.
     */
    private boolean checkSameNameAndNum(String nameOfAthlete, String numberOfAthlete){
        for(LongJumpResult longJumpResult : this.JUMP_RESULT_REGISTER){
            if(nameOfAthlete.equals(longJumpResult.getATHLETE_NAME())){
                if(!numberOfAthlete.equals(longJumpResult.getSTART_NUMBER())){
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * This method calculates the average jump length of all the entries in the registry. The average is calculated
     * by adding up all the jumps and then dividing that total by the number of entries.
     * @return A double showing the average jump length of the registered jumps.
     */
    public double calcAverageJump(){
        double totalJumpLength = 0;
        for(LongJumpResult longJumpResult : this.JUMP_RESULT_REGISTER){
            totalJumpLength += longJumpResult.getJUMP_RESULT();
        }
        double averageJumpLength = totalJumpLength / this.JUMP_RESULT_REGISTER.size();
        return averageJumpLength;
    }

    /**
     * This method creates a list of all the events that occur before the given time.
     * @param time The time for which the user wants to check the events before.
     * @return A list of all the events before the given time.
     */
    public List<LongJumpResult> eventsBefore(LocalTime time){
        List<LongJumpResult> eventsBeforeList = new ArrayList<>();
        for(LongJumpResult longJumpResult : JUMP_RESULT_REGISTER){
            if(longJumpResult.getTIME_OF_JUMP().isBefore(time)){
                eventsBeforeList.add(longJumpResult);
            }
        }
        return deepCopyList(eventsBeforeList);
    }

    /**
     * This method creates a list of all the events that occur after the given time.
     * @param time The time for which the user wants to check the events after.
     * @return A list of all the events after the given time.
     */
    public List<LongJumpResult> eventsAfter(LocalTime time){
        List<LongJumpResult> eventsAfterList = new ArrayList<>();
        for(LongJumpResult longJumpResult : JUMP_RESULT_REGISTER){
            if(longJumpResult.getTIME_OF_JUMP().isAfter(time)){
                eventsAfterList.add(longJumpResult);
            }
        }
        return deepCopyList(eventsAfterList);
    }

    /**
     * This is a method that deepCopies a given list with object type LongJumpResult. Since a lot of deep copies need
     * to be made in the different methods in this class, this method reduces repetition.
     * @param longJumpList A list of LongJumpResult objects.
     * @return A deep copied version of the list sent in.
     */
    private List<LongJumpResult> deepCopyList(List<LongJumpResult> longJumpList){
        List<LongJumpResult> copiedList = new ArrayList<>();
        for(LongJumpResult longJumpResult : longJumpList){
            copiedList.add(new LongJumpResult(longJumpResult));
        }
        return copiedList;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\t\t").append(this.NAME_OF_EVENT).append("\n");
        for(LongJumpResult longJumpResult : this.JUMP_RESULT_REGISTER){
            sb.append(longJumpResult).append("\n");
        }
        return sb.toString();
    }
}
