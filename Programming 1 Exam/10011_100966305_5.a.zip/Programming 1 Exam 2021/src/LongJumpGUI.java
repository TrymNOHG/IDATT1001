import java.time.LocalTime;
import java.util.Scanner;

/**
 * This is the basic user interface for the Long Jump Register application.
 *
 * @author 10011
 */
public class LongJumpGUI {

    private static Scanner input = new Scanner(System.in);
    private static final int ADD_RESULT = 1;
    private static final int LIST_ALL_RESULTS = 2;
    private static final int SHOW_RESULT_BY_ATHLETE = 3;
    private static final int SHOW_SINGLE_BEST = 4;
    private static final int SHOW_BEST_RESULTS = 5;
    private static final int CALCULATE_AVERAGE_RESULT = 6;
    private static final int FIND_BEFORE_TIME = 7;
    private static final int FIND_AFTER_TIME = 8;
    private static final int EXIT = 9;
    private final JumpResultRegister RESULT_REGISTER;

    public LongJumpGUI() {
        this.RESULT_REGISTER = new JumpResultRegister("Olympic Games 2021");
    }

    /**
     * This method shows the menu to the user and then waits for the user to enter a number, an input.
     * That input is then used as the number of the case wanted and is returned by this method, if it is
     * a correct input type.
     *
     * @return The menu choice input by user
     */
    private int getMenuChoice() {
        int menuChoice = 0;
        System.out.println("\n***** Long Jump Register Application v0.1 *****\n");
        System.out.println("1. Add a new result");
        System.out.println("2. Show all the current entries");
        System.out.println("3. Show all the entries of a given athlete");
        System.out.println("4. Show the best entries");
        System.out.println("5. Show the top 3 best entries");
        System.out.println("6. Show the average length jumped");
        System.out.println("7. Show events before a given time");
        System.out.println("8. Show events after a given time");
        System.out.println("9. Quit");
        System.out.println("\nPlease enter a number between 1 and 9.\n");
        Scanner sc = new Scanner(System.in);
        if (sc.hasNextInt()) {
            menuChoice = sc.nextInt();
        } else {
            System.out.println("You must enter a number, not text");
        }
        return menuChoice;
    }

    /**
     * This method starts the program by starting a while loop, which goes through a switch. It, then,
     * retrieves the menu choice by calling getMenuChoice {@link #getMenuChoice()}.
     *
     * Starts the application. This is the main loop of the application,
     * presenting the menu, retrieving the selected menu choice from the user,
     * and executing the selected functionality.
     */
    public void start() {
        boolean finished = false;
        while (!finished) {
            int menuChoice = this.getMenuChoice();
            try {
                switch (menuChoice) {
                    case ADD_RESULT:
                        addNewResult();
                        break;

                    case LIST_ALL_RESULTS:
                        listAllResults();
                        break;

                    case SHOW_RESULT_BY_ATHLETE:
                        showResultByAthlete();
                        break;
                    case SHOW_SINGLE_BEST:
                        showSingleBestResult();
                        break;

                    case SHOW_BEST_RESULTS:
                        showBestResults();
                        break;

                    case CALCULATE_AVERAGE_RESULT:
                        calculateAverageResult();
                        break;

                    case FIND_BEFORE_TIME:
                        beforeTime();
                        break;

                    case FIND_AFTER_TIME:
                        afterTime();
                        break;

                    case EXIT:
                        System.out.println("Thank you for using this application!");
                        finished = true;
                        break;

                    default:
                        System.out.println("Unrecognized menu selected..");
                        break;
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * This method obtains all the input necessary to add a new result into the registry. The method, then, proceeds
     * to attempt to register the entry via the registerNewJump method
     * {@link JumpResultRegister#registerNewJump(String, String, double, boolean, LocalTime)}.
     */
    private void addNewResult(){
        System.out.println("First, to add a new entry into the register, you need to enter the athlete's start number." +
                "This may either be a number or the last name of the athlete.");
        String startNum = input.nextLine();
        System.out.println("Now, enter the athlete's full name.");
        String athleteName = input.nextLine();
        System.out.println("Please, enter the jump distance in meters: f.eks 5.87");
        double jumpLength = input.nextDouble();
        input.nextLine();
        System.out.println("If the entry was valid, type (Y)es. If it was invalid, (N)o");
        String foulString = input.nextLine().toUpperCase().trim();
        boolean foul = false;
        if(foulString.charAt(0) == 'N'){
            foul = true;
        }
        System.out.println("Finally, you need to enter the time of the jump.");
        LocalTime longJumpTime = jumpTime();

        if(this.RESULT_REGISTER.registerNewJump(startNum, athleteName, jumpLength, foul, longJumpTime)){
            System.out.println("You have successfully added a new jump to the registry!");
        }
        else{
            System.out.println("The logging of the jump was unsuccessfully. This entry may already exist in the registry.");
        }
    }

    /**
     * This method prints out all the information to all the entries in the register currently. It does so through
     * implicitly using the toString in the JumpResultRegister {@link JumpResultRegister#toString()}
     * and the listAllJumps method {@link JumpResultRegister#listAllJumps()}.
     */
    private void listAllResults(){
        System.out.println("The following are all the entries registered: ");
        for(LongJumpResult longJumpResult : this.RESULT_REGISTER.listAllJumps()){
            System.out.println(longJumpResult + "\n");
        }
    }

    /**
     * This method prints out all the entries from a given athlete {@link JumpResultRegister#resultByAthlete(String)}.
     */
    private void showResultByAthlete(){
        System.out.println("What is the name of the athlete that you want to check?");
        String athleteName = input.nextLine();
        System.out.println(this.RESULT_REGISTER.resultByAthlete(athleteName));
    }

    /**
     * This is the method used to find the single best result out of all the entries {@link JumpResultRegister#bestResults(int)}.
     */
    private void showSingleBestResult(){
        System.out.println("The best result so far is: \n");
        System.out.println(this.RESULT_REGISTER.bestResults(1));

    }

    /**
     * This method prints out the best results out of all the entries in the register
     * {@link JumpResultRegister#bestResults(int)}.
     */
    private void showBestResults(){
        System.out.println("The best results are: \n");
        for(int i = 0; i < this.RESULT_REGISTER.bestResults(3).size(); i++){
            System.out.println((i+1) + ". " + this.RESULT_REGISTER.bestResults(3).get(i) + "\n");
        }
    }

    /**
     * This method prints out the average length of all the jumps in the registry
     * {@link JumpResultRegister#calcAverageJump()}.
     */
    private void calculateAverageResult(){
        System.out.println("The average length jumped was " + this.RESULT_REGISTER.calcAverageJump() + " meters!");
    }

    /**
     * This method finds all the events before the time given by the user, through the jumpTime method {@link #jumpTime()}.
     */
    private void beforeTime(){
        System.out.println("To find the time before, first answer these questions: ");
        System.out.println(this.RESULT_REGISTER.eventsBefore(jumpTime()));
    }

    /**
     * This method finds all the events after the time given by the user, through the jumpTime method {@link #jumpTime()}.
     */
    private void afterTime(){
        System.out.println("To find the time after, first answer these questions: ");
        System.out.println(this.RESULT_REGISTER.eventsAfter(jumpTime()));
    }

    /**
     * This method asks the user for a time in hours and minutes. This time is then parsed and made into a LocalTime
     * object. If the hours or minutes are wrong, then an IllegalArgumentException is thrown.
     * @return A LocalTime object representing the time given by the user.
     */
    private LocalTime jumpTime(){
        System.out.println("What was the hour when the jump occurred? Type in the form HH, f.eks 10");
        int hoursInt = input.nextInt();
        String hours = String.valueOf(hoursInt);

        System.out.println("What was the minutes when the jump occurred? Type in the form MM, f.eks 32");
        int minutesInt = input.nextInt();
        String minutes = String.valueOf(minutesInt);
        input.nextLine();

        if(hoursInt < 0 || hoursInt > 23) throw new IllegalArgumentException("You have entered an invalid hour!");
        else if(hoursInt > 0 && hoursInt < 10){
            hours = "0" + hours;
        }

        if(minutesInt < 0 || minutesInt > 59) throw new IllegalArgumentException("You have entered an invalid minute");
        else if(minutesInt > 0 && minutesInt < 10){
            minutes = "0" + minutes;
        }

        return LocalTime.parse(hours + ":" + minutes);
    }

}

