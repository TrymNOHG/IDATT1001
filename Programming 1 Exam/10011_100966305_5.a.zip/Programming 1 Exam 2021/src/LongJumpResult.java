import java.time.LocalTime;

/**
 * This class represents a long jump result entry. It, therefore, handles all the information concerning an entry such
 * as the athlete's start number, their name, the jump length, whether the jump was valid, and the time of the jump.
 * No mutator methods were used in this class since once the entry has been placed there is no need to change it.
 *
 * @author 10011
 */
public class LongJumpResult {
    private final String START_NUMBER; //Can be the athletes last name or a number. Maybe regex?
    private final String ATHLETE_NAME; //Should be full name with first and last name.
    private final double JUMP_RESULT;
    private final boolean FOUL;
    private final LocalTime TIME_OF_JUMP;

    /**
     * This is a constructor representing the object LongJumpResult. It, therefore, has all the necessary information
     * to describe a long jump result. Additionally, the constructor checks for invalid input such as if the start
     * number or athlete name is left blank or if the jump result is a negative number. Then, an illegal argument
     * exception is thrown.
     * @param START_NUMBER A string representing an athletes start number.
     * @param ATHLETE_NAME A string for the athlete's name.
     * @param JUMP_RESULT A double for the length jumped by the athlete.
     * @param FOUL A boolean stating whether the jump was a foul or not. If true, then the jump was invalid.
     * @param TIME_OF_JUMP The time of the jump in hours:minutes:seconds.
     */
    public LongJumpResult(String START_NUMBER, String ATHLETE_NAME, double JUMP_RESULT, boolean FOUL, LocalTime TIME_OF_JUMP) {
        if(START_NUMBER.isBlank()) throw new IllegalArgumentException("The start number cannot be blank!");
        if(ATHLETE_NAME.isBlank()) throw new IllegalArgumentException("The athlete name cannot be blank!");
        if(ATHLETE_NAME.split(" ").length < 2) throw new IllegalArgumentException("You need to enter both a first " +
                "and last name for the athlete");
        if(JUMP_RESULT < 0) throw new IllegalArgumentException("The jump result cannot be a negative distance!");
        this.START_NUMBER = START_NUMBER.toUpperCase();
        this.ATHLETE_NAME = ATHLETE_NAME.toUpperCase();
        this.JUMP_RESULT = JUMP_RESULT;
        this.FOUL = FOUL;
        this.TIME_OF_JUMP = TIME_OF_JUMP;
    }

    /**
     * This is a constructor which copies all of the primitive variables/values of one object and creates a new object
     * using those variables. It takes in a LongJumpResult object and uses the constructor with 5 variables, using
     * this(), to create a new object.
     * @param longJumpResult A LongJumpResult object, which will have its variables copied.
     */
    public LongJumpResult(LongJumpResult longJumpResult) {
        this(longJumpResult.getSTART_NUMBER(), longJumpResult.getATHLETE_NAME(), longJumpResult.getJUMP_RESULT(), longJumpResult.isFOUL(), longJumpResult.getTIME_OF_JUMP());
    }

    /**
     * This method retrieves the start number of the athlete.
     * @return A string containing the start number of the athlete.
     */
    public String getSTART_NUMBER() {
        return START_NUMBER;
    }

    /**
     * This method retrieves the athletes full name.
     * @return A string containing the athlete's name.
     */
    public String getATHLETE_NAME() {
        return ATHLETE_NAME;
    }

    /**
     * This method retrieves the jump result of a given athelete.
     * @return A double representing the length jumped.
     */
    public double getJUMP_RESULT() {
        return JUMP_RESULT;
    }

    /**
     * This method retrieves the status of whether the jump of an athlete was a foul or not.
     * @return A boolean representing the validity of the jump. If valid, then false is returned. If invalid, then true.
     */
    public boolean isFOUL() {
        return FOUL;
    }

    /**
     * This method retrieves the time of the jump.
     * @return A LocalTime object containing the time of the athlete's jump.
     */
    public LocalTime getTIME_OF_JUMP() {
        return TIME_OF_JUMP;
    }

    /**
     * This is a toString, where the given object's object variables are returned as a String. StringBuilder was used
     * here in order to minimize the amount of garbage collection needed, since it is mutable while String is immutable.
     * @return A string with LongJumpResult's information.
     */
    @Override
    public String toString() {
        String jumpStatus = "Valid jump";
        if(FOUL) jumpStatus = "Invalid jump";
        StringBuilder sb = new StringBuilder();
        sb.append("Athlete:  ").append(ATHLETE_NAME).append("\nJump: ").append(JUMP_RESULT).append("m\nJump status: ");
        sb.append(jumpStatus).append("\nTime of ").append("jump:  ").append(TIME_OF_JUMP.toString());
        return  sb.toString();
    }
}
