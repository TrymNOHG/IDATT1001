public class Main {
    public static void main(String[] args) {
        LongJumpGUI longJumpGUI = new LongJumpGUI();
        longJumpGUI.start();
    }
}
